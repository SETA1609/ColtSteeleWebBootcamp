import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';
import Property from './Property/Property';

export default function PropertyList({properties}) {
    return (
        <div className='row'>
            <ul className='d-flex ' >
                {properties.map((property) => (
                    <div key={property.id} className='card'>
                        <Property {...property} />
                    </div>
                ))}
            </ul>
        </div>
    )
}
