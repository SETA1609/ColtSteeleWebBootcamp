import React from 'react'

export default function Property({ name, rating, price }) {
    return (
        <li>
            <h1>{name}</h1>
            <h2>✨{rating}</h2>
            <h3>🪙{price}</h3>
        </li>
    )
}
