
import './App.css';
import RandomPokemon from './modules/RandomPokemon';
function App() {
  return (
  <div className='PokemonAlbum'>
    <div className='Pokemon-Card'>
      <RandomPokemon />
    </div>
    <div className='Pokemon-Card'>
      <RandomPokemon />
    </div>
    <div className='Pokemon-Card'>
      <RandomPokemon />
    </div>
  </div>
  );
}

export default App;
