# Pokedex150
Colt Steele exercise for React
